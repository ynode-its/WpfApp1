﻿// Retry.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include <windows.h>
#include <iostream>
#include <sddl.h>


int CloneProcess(LPSTR cmdline)
{
    STARTUPINFOA si = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION pi = {};


    BOOL success = CreateProcess(
        NULL,     // 実行ファイルのパス（cmdlineから取得）
        cmdline,      // コマンドライン（書き換え可）
        NULL,     // プロセスセキュリティ属性
        NULL,     // スレッドセキュリティ属性
        FALSE,    // ハンドル継承なし
        0,        // 通常起動
        NULL,     // 親の環境変数継承
        NULL,     // カレントディレクトリ継承
        &si,      // STARTUPINFO
        &pi       // 結果（PROCESS_INFORMATION）
    );

    if (success) {
        // ハンドル解放を忘れずに
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
    else {
        std::cerr << "CreateProcess failed. Error: " << GetLastError() << std::endl;
    }

    return 0;
}

void log(char* log)
{
    HANDLE hMutexlog = CreateMutexA(
        NULL,            // デフォルトのセキュリティ属性
        TRUE,            // このプロセスが所有者になる
        "testlog" // グローバル名前付きミューテックス名
    );
    if (hMutexlog == NULL) {
        std::cerr << "CreateMutex failed: " << GetLastError() << std::endl;
        return;
    }
    DWORD result = WaitForSingleObject(hMutexlog, 10000);
    switch (result) {
    case WAIT_OBJECT_0:
        std::cout << "ミューテックス取得成功\n";
        printf(log);
        ReleaseMutex(hMutexlog);
        break;
    case WAIT_TIMEOUT:
        std::cout << "\u001b[31m timeout \u001b[00m \n";
        break;
    case WAIT_ABANDONED:
        std::cout << "\u001b[31m ABANDONED \u001b[00m \n";
        ReleaseMutex(hMutexlog);
        break;
    case WAIT_FAILED:
        std::cerr << "Wait失敗: " << GetLastError() << std::endl;
        break;
    }
    CloseHandle(hMutexlog);
}

int SerachFile(char* name) {
    WIN32_FIND_DATA findFileData;
    HANDLE hFind;

    char crtPath[MAX_PATH];
    char delPath[MAX_PATH];
    char path[MAX_PATH];
    DWORD len = GetModuleFileNameA(NULL, path, MAX_PATH);
    path[len - 4] = '\0';

    if (INVALID_FILE_ATTRIBUTES == ::GetFileAttributesA(path))
    {
        CreateDirectory(path, NULL);
    }
    strcat_s(path, 260, "\\");
    strcat_s(path, 260, name);
    strcpy_s(crtPath, 260, path);

    if (INVALID_FILE_ATTRIBUTES == ::GetFileAttributesA(path))
    {
        CreateDirectory(path, NULL);
    }

    strcat_s(path, 260, "\\*");

    int retry = 0;
    do {
        hFind = FindFirstFile(path, &findFileData);

        if (hFind == INVALID_HANDLE_VALUE) {
            std::cerr << "FindFirstFile failed (" << GetLastError() << ")\n";
            return 1;
        }
        do {
            if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
            {
                continue;
            }
            char logs[256];

            sprintf_s(logs, 256, "%d%s%s\n", GetCurrentProcessId(), ":Found: ", findFileData.cFileName);
            log(logs);

            sprintf_s(delPath, 260, "%s\\%s", crtPath, findFileData.cFileName);
            if (0 != remove(delPath))
            {
                printf("\u001b[31m remove(%s)=%d \u001b[00m \n", delPath, GetLastError());
            }
        } while (FindNextFile(hFind, &findFileData) != 0);
        FindClose(hFind);
        retry++;
        Sleep(200);
    } while (3 > retry);

    return 0;
}

HANDLE hMutex;
PSECURITY_DESCRIPTOR pSD = NULL;


int testprocess(int argc, char* argv[])
{
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES) };
    int pno = atoi(argv[2]);
    char mname[256];
    char name[256];

    sprintf_s(name, 256, "%s%s", argv[1], argv[2]);
    sprintf_s(mname, 256,  "Global\\%s", name);


    // "D:(A;;GA;;;WD)" = Everyone に対して Generic All 権限を許可
    if (!ConvertStringSecurityDescriptorToSecurityDescriptorA(
        "D:(A;;GA;;;WD)", // SDDL 文字列
        SDDL_REVISION_1,
        &pSD,
        NULL)) {
        std::cerr << "セキュリティ記述子の変換に失敗しました: " << GetLastError() << std::endl;
        return 1;
    }
    sa.lpSecurityDescriptor = pSD;
    sa.bInheritHandle = FALSE;

    hMutex = CreateMutexA(
        &sa,            // デフォルトのセキュリティ属性
        TRUE,            // このプロセスが所有者になる
        mname // グローバル名前付きミューテックス名
    );
    // 作成に失敗した場合
    if (hMutex == NULL) {
        std::cerr << "CreateMutex failed: " << GetLastError() << std::endl;
        return 1;
    }

    // すでに存在する場合（他のプロセスが保持している）
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        std::cout << "他のインスタンスがすでに起動中です。" << mname << GetCurrentProcessId() << std::endl;
        return 1;
    }
    std::cout << "このプロセスが唯一のインスタンスです。" << mname << std::endl;

    SerachFile(name);

    return 0;
}
void CreateTrg(char* trg)
{
    HANDLE hFile = CreateFile(trg, GENERIC_WRITE, 0,NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    CloseHandle(hFile);
}

int mainprocess(int argc, char* argv[])
{
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES) };
    char path[MAX_PATH];
    char cmdline[MAX_PATH];
    DWORD len = GetModuleFileNameA(NULL, path, MAX_PATH);

    // "D:(A;;GA;;;WD)" = Everyone に対して Generic All 権限を許可
    if (!ConvertStringSecurityDescriptorToSecurityDescriptorA(
        "D:(A;;GA;;;WD)", // SDDL 文字列
        SDDL_REVISION_1,
        &pSD,
        NULL)) {
        std::cerr << "セキュリティ記述子の変換に失敗しました: " << GetLastError() << std::endl;
        return 1;
    }

    sa.lpSecurityDescriptor = pSD;
    sa.bInheritHandle = FALSE;

    hMutex = CreateMutexA(
        &sa,            // デフォルトのセキュリティ属性
        TRUE,            // このプロセスが所有者になる
        "Global\\MyUniqueAppMutex" // グローバル名前付きミューテックス名
    );
    // 作成に失敗した場合
    if (hMutex == NULL) {
        std::cerr << "CreateMutex failed: " << GetLastError() << std::endl;
        return 1;
    }

    // すでに存在する場合（他のプロセスが保持している）
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        std::cout << "他のインスタンスがすでに起動中です。" << GetCurrentProcessId() << std::endl;
        return 1;
    }

    // このプロセスが唯一のインスタンスとして動作中
    std::cout << "このプロセスが唯一のインスタンスです。" << std::endl;

    for (int pcnt = 0; pcnt < 50; pcnt++)
    {
        for (int fcnt = 0; fcnt < 20; fcnt++)
        {
            strcpy_s(cmdline, 260, path);
            sprintf_s(&cmdline[len - 4], 260 - len - 4, "\\test%04d\\trg%04d.trg", pcnt, fcnt);
            CreateTrg(cmdline);
        }
        sprintf_s(cmdline, 260, "%s test %04d", path, pcnt);
        CloneProcess(cmdline);
    }


	return 0;
}

int main(int argc, char* argv[])
{
    std::cout << "プロセス起動成功！ PID: " << GetCurrentProcessId() << std::endl;
    if (argc == 1)
    {
        int ret = mainprocess(argc, argv);
        if (0 == ret)
        {
            // ↓↓ 本来の処理を書く（今回は Enter キー待ちで保持）
            //std::cout << "処理中...（Enter キーで終了）" << GetCurrentProcessId() << std::endl;
            //std::cin.get();
        }
        // ミューテックスを解放して終了
        ReleaseMutex(hMutex);
        CloseHandle(hMutex);
        LocalFree(pSD);
    }
    else if (argc == 3 && 0 == strcmp(argv[1], "test"))
    {
        std::cout << argv[1] << argv[2] << std::endl;
        int ret = testprocess(argc, argv);
        // ミューテックスを解放して終了
        ReleaseMutex(hMutex);
        CloseHandle(hMutex);
        LocalFree(pSD);
    }

    return 0;
}
